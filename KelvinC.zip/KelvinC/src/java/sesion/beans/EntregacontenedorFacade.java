/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package sesion.beans;

import entidades.Entregacontenedor;
import javax.ejb.Stateless;
import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

/**
 *
 * @author informatica
 */
@Stateless
public class EntregacontenedorFacade extends AbstractFacade<Entregacontenedor> {

    @PersistenceContext(unitName = "KelvinCPU")
    private EntityManager em;

    @Override
    protected EntityManager getEntityManager() {
        return em;
    }

    public EntregacontenedorFacade() {
        super(Entregacontenedor.class);
    }
    
}
