/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import entidades.Camion;
import entidades.Empleado;
import entidades.Entrega;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;

/**
 *
 * @author alfi
 */
@ManagedBean(name = "entregasActivas")
@ViewScoped
public class EntregasActivas implements Serializable{

    private Query q;
    private List<Entrega> entregasLst;
    private String estado;
    private String dui;
    private String placa;
    private List<Empleado> empleado;
    private List<Camion> camion;

    public EntregasActivas() {
    }

    @PostConstruct
    public void Init() {
        buscarEntregasActivas();
    }

    public void buscarEmpleado() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("KelvinCPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT * FROM empleado WHERE empleado.duiempleado = '" + this.dui + "'";
        q = em.createNativeQuery(jpql);
        this.empleado = q.getResultList();
        em.close();
        emf.close();

    }
    public void buscarCamion() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("KelvinCPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT * FROM camion WHERE camion.placacamion = '" + this.placa + "'";
        q = em.createNativeQuery(jpql);
        this.camion = q.getResultList();
        em.close();
        emf.close();

    }

    public void buscarEntregasActivas() {
        estado = "ENTREGAS ACTIVAS";
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("KelvinCPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT entrega.codigoentrega, entrega.fechaentrega, \n"
                + "empleado.nombreempleado||' '||empleado.apellidoempleado\n"
                + "as nombre, camion.placacamion, canton.nombrecanton, empleado.duiempleado, camion.placacamion FROM\n"
                + "entrega INNER JOIN camion ON entrega.placacamion= camion.placacamion\n"
                + "INNER JOIN empleado ON entrega.duiempleado = empleado.duiempleado\n"
                + "INNER JOIN canton ON entrega.codigocantonentrega = canton.codigocanton\n"
                + "WHERE NOT EXISTS(SELECT * FROM devolucion WHERE devolucion.codigoentrega = entrega.codigoentrega)";
        q = em.createNativeQuery(jpql);
        entregasLst = q.getResultList();
        em.close();
        emf.close();

    }

    public void buscarEntregasFinalizadas() {
        estado = "ENTREGAS FINALIZADAS";
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("KelvinCPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT entrega.codigoentrega, entrega.fechaentrega, \n"
                + "empleado.nombreempleado||' '||empleado.apellidoempleado\n"
                + "as nombre, camion.placacamion, canton.nombrecanton, empleado.duiempleado, camion.placacamion FROM\n"
                + "entrega INNER JOIN camion ON entrega.placacamion= camion.placacamion\n"
                + "INNER JOIN empleado ON entrega.duiempleado = empleado.duiempleado\n"
                + "INNER JOIN canton ON entrega.codigocantonentrega = canton.codigocanton\n"
                + "INNER JOIN devolucion ON entrega.codigoentrega = devolucion.codigoentrega";
        q = em.createNativeQuery(jpql);
        entregasLst = q.getResultList();
        em.close();
        emf.close();

    }

    public List<Entrega> getEntregasLst() {
        return entregasLst;
    }

    public String getEstado() {
        return estado;
    }

    public String getDui() {
        return dui;
    }

    public void setDui(String dui) {
        this.dui = dui;
    }

    public List<Empleado> getEmpleado() {
        return empleado;
    }

    public void setEmpleado(List<Empleado> empleado) {
        this.empleado = empleado;
    }

    public String getPlaca() {
        return placa;
    }

    public void setPlaca(String placa) {
        this.placa = placa;
    }

    public List<Camion> getCamion() {
        return camion;
    }

    public void setCamion(List<Camion> camion) {
        this.camion = camion;
    }

}
