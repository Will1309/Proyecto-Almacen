/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "empleado")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Empleado.findAll", query = "SELECT e FROM Empleado e")
    , @NamedQuery(name = "Empleado.findByDuiempleado", query = "SELECT e FROM Empleado e WHERE e.duiempleado = :duiempleado")
    , @NamedQuery(name = "Empleado.findByNombreempleado", query = "SELECT e FROM Empleado e WHERE e.nombreempleado = :nombreempleado")
    , @NamedQuery(name = "Empleado.findByApellidoempleado", query = "SELECT e FROM Empleado e WHERE e.apellidoempleado = :apellidoempleado")
    , @NamedQuery(name = "Empleado.findByEstadoempleado", query = "SELECT e FROM Empleado e WHERE e.estadoempleado = :estadoempleado")
    , @NamedQuery(name = "Empleado.findByFechacontrato", query = "SELECT e FROM Empleado e WHERE e.fechacontrato = :fechacontrato")
    , @NamedQuery(name = "Empleado.findBySalario", query = "SELECT e FROM Empleado e WHERE e.salario = :salario")
    , @NamedQuery(name = "Empleado.findByGenero", query = "SELECT e FROM Empleado e WHERE e.genero = :genero")
    , @NamedQuery(name = "Empleado.findByFechanacimiento", query = "SELECT e FROM Empleado e WHERE e.fechanacimiento = :fechanacimiento")})
public class Empleado implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "duiempleado")
    private String duiempleado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "nombreempleado")
    private String nombreempleado;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "apellidoempleado")
    private String apellidoempleado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estadoempleado")
    private boolean estadoempleado;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechacontrato")
    @Temporal(TemporalType.DATE)
    private Date fechacontrato;
    @Basic(optional = false)
    @NotNull
    @Column(name = "salario")
    private float salario;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 15)
    @Column(name = "genero")
    private String genero;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechanacimiento")
    @Temporal(TemporalType.DATE)
    private Date fechanacimiento;
    @JoinColumn(name = "codigocargo", referencedColumnName = "codigocargo")
    @ManyToOne(optional = false)
    private Cargo codigocargo;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "duiempleado")
    private List<Entrega> entregaList;
    @OneToOne(cascade = CascadeType.ALL, mappedBy = "empleado")
    private Usuario usuario;

    public Empleado() {
    }

    public Empleado(String duiempleado) {
        this.duiempleado = duiempleado;
    }

    public Empleado(String duiempleado, String nombreempleado, String apellidoempleado, boolean estadoempleado, Date fechacontrato, float salario, String genero, Date fechanacimiento) {
        this.duiempleado = duiempleado;
        this.nombreempleado = nombreempleado;
        this.apellidoempleado = apellidoempleado;
        this.estadoempleado = estadoempleado;
        this.fechacontrato = fechacontrato;
        this.salario = salario;
        this.genero = genero;
        this.fechanacimiento = fechanacimiento;
    }

    public String getDuiempleado() {
        return duiempleado;
    }

    public void setDuiempleado(String duiempleado) {
        this.duiempleado = duiempleado;
    }

    public String getNombreempleado() {
        return nombreempleado;
    }

    public void setNombreempleado(String nombreempleado) {
        this.nombreempleado = nombreempleado;
    }

    public String getApellidoempleado() {
        return apellidoempleado;
    }

    public void setApellidoempleado(String apellidoempleado) {
        this.apellidoempleado = apellidoempleado;
    }

    public boolean getEstadoempleado() {
        return estadoempleado;
    }

    public void setEstadoempleado(boolean estadoempleado) {
        this.estadoempleado = estadoempleado;
    }

    public Date getFechacontrato() {
        return fechacontrato;
    }

    public void setFechacontrato(Date fechacontrato) {
        this.fechacontrato = fechacontrato;
    }

    public float getSalario() {
        return salario;
    }

    public void setSalario(float salario) {
        this.salario = salario;
    }

    public String getGenero() {
        return genero;
    }

    public void setGenero(String genero) {
        this.genero = genero;
    }

    public Date getFechanacimiento() {
        return fechanacimiento;
    }

    public void setFechanacimiento(Date fechanacimiento) {
        this.fechanacimiento = fechanacimiento;
    }

    public Cargo getCodigocargo() {
        return codigocargo;
    }

    public void setCodigocargo(Cargo codigocargo) {
        this.codigocargo = codigocargo;
    }

    @XmlTransient
    public List<Entrega> getEntregaList() {
        return entregaList;
    }

    public void setEntregaList(List<Entrega> entregaList) {
        this.entregaList = entregaList;
    }

    public Usuario getUsuario() {
        return usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (duiempleado != null ? duiempleado.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Empleado)) {
            return false;
        }
        Empleado other = (Empleado) object;
        if ((this.duiempleado == null && other.duiempleado != null) || (this.duiempleado != null && !this.duiempleado.equals(other.duiempleado))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Empleado[ duiempleado=" + duiempleado + " ]";
    }
    
}
