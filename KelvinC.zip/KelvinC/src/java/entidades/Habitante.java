/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "habitante")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Habitante.findAll", query = "SELECT h FROM Habitante h")
    , @NamedQuery(name = "Habitante.findByDuihabitante", query = "SELECT h FROM Habitante h WHERE h.duihabitante = :duihabitante")
    , @NamedQuery(name = "Habitante.findByNombrehabitante", query = "SELECT h FROM Habitante h WHERE h.nombrehabitante = :nombrehabitante")
    , @NamedQuery(name = "Habitante.findByApellidohabitante", query = "SELECT h FROM Habitante h WHERE h.apellidohabitante = :apellidohabitante")
    , @NamedQuery(name = "Habitante.findByDireccion", query = "SELECT h FROM Habitante h WHERE h.direccion = :direccion")})
public class Habitante implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 10)
    @Column(name = "duihabitante")
    private String duihabitante;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "nombrehabitante")
    private String nombrehabitante;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "apellidohabitante")
    private String apellidohabitante;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "direccion")
    private String direccion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "duihabitante")
    private List<Entregahabitante> entregahabitanteList;
    @JoinColumn(name = "codigocanton", referencedColumnName = "codigocanton")
    @ManyToOne(optional = false)
    private Canton codigocanton;

    public Habitante() {
    }

    public Habitante(String duihabitante) {
        this.duihabitante = duihabitante;
    }

    public Habitante(String duihabitante, String nombrehabitante, String apellidohabitante, String direccion) {
        this.duihabitante = duihabitante;
        this.nombrehabitante = nombrehabitante;
        this.apellidohabitante = apellidohabitante;
        this.direccion = direccion;
    }

    public String getDuihabitante() {
        return duihabitante;
    }

    public void setDuihabitante(String duihabitante) {
        this.duihabitante = duihabitante;
    }

    public String getNombrehabitante() {
        return nombrehabitante;
    }

    public void setNombrehabitante(String nombrehabitante) {
        this.nombrehabitante = nombrehabitante;
    }

    public String getApellidohabitante() {
        return apellidohabitante;
    }

    public void setApellidohabitante(String apellidohabitante) {
        this.apellidohabitante = apellidohabitante;
    }

    public String getDireccion() {
        return direccion;
    }

    public void setDireccion(String direccion) {
        this.direccion = direccion;
    }

    @XmlTransient
    public List<Entregahabitante> getEntregahabitanteList() {
        return entregahabitanteList;
    }

    public void setEntregahabitanteList(List<Entregahabitante> entregahabitanteList) {
        this.entregahabitanteList = entregahabitanteList;
    }

    public Canton getCodigocanton() {
        return codigocanton;
    }

    public void setCodigocanton(Canton codigocanton) {
        this.codigocanton = codigocanton;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (duihabitante != null ? duihabitante.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Habitante)) {
            return false;
        }
        Habitante other = (Habitante) object;
        if ((this.duihabitante == null && other.duihabitante != null) || (this.duihabitante != null && !this.duihabitante.equals(other.duihabitante))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Habitante[ duihabitante=" + duihabitante + " ]";
    }
    
}
