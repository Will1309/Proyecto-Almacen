/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "entrega")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Entrega.findAll", query = "SELECT e FROM Entrega e")
    , @NamedQuery(name = "Entrega.findByFechaentrega", query = "SELECT e FROM Entrega e WHERE e.fechaentrega = :fechaentrega")
    , @NamedQuery(name = "Entrega.findByCodigoentrega", query = "SELECT e FROM Entrega e WHERE e.codigoentrega = :codigoentrega")})
public class Entrega implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaentrega")
    @Temporal(TemporalType.DATE)
    private Date fechaentrega;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigoentrega")
    private Short codigoentrega;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codigoentrega")
    private List<Devolucion> devolucionList;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codigoentrega")
    private List<Entregacontenedor> entregacontenedorList;
    @JoinColumn(name = "placacamion", referencedColumnName = "placacamion")
    @ManyToOne(optional = false)
    private Camion placacamion;
    @JoinColumn(name = "codigocantonentrega", referencedColumnName = "codigocanton")
    @ManyToOne(optional = false)
    private Canton codigocantonentrega;
    @JoinColumn(name = "duiempleado", referencedColumnName = "duiempleado")
    @ManyToOne(optional = false)
    private Empleado duiempleado;

    public Entrega() {
    }

    public Entrega(Short codigoentrega) {
        this.codigoentrega = codigoentrega;
    }

    public Entrega(Short codigoentrega, Date fechaentrega) {
        this.codigoentrega = codigoentrega;
        this.fechaentrega = fechaentrega;
    }

    public Date getFechaentrega() {
        return fechaentrega;
    }

    public void setFechaentrega(Date fechaentrega) {
        this.fechaentrega = fechaentrega;
    }

    public Short getCodigoentrega() {
        return codigoentrega;
    }

    public void setCodigoentrega(Short codigoentrega) {
        this.codigoentrega = codigoentrega;
    }

    @XmlTransient
    public List<Devolucion> getDevolucionList() {
        return devolucionList;
    }

    public void setDevolucionList(List<Devolucion> devolucionList) {
        this.devolucionList = devolucionList;
    }

    @XmlTransient
    public List<Entregacontenedor> getEntregacontenedorList() {
        return entregacontenedorList;
    }

    public void setEntregacontenedorList(List<Entregacontenedor> entregacontenedorList) {
        this.entregacontenedorList = entregacontenedorList;
    }

    public Camion getPlacacamion() {
        return placacamion;
    }

    public void setPlacacamion(Camion placacamion) {
        this.placacamion = placacamion;
    }

    public Canton getCodigocantonentrega() {
        return codigocantonentrega;
    }

    public void setCodigocantonentrega(Canton codigocantonentrega) {
        this.codigocantonentrega = codigocantonentrega;
    }

    public Empleado getDuiempleado() {
        return duiempleado;
    }

    public void setDuiempleado(Empleado duiempleado) {
        this.duiempleado = duiempleado;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoentrega != null ? codigoentrega.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Entrega)) {
            return false;
        }
        Entrega other = (Entrega) object;
        if ((this.codigoentrega == null && other.codigoentrega != null) || (this.codigoentrega != null && !this.codigoentrega.equals(other.codigoentrega))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Entrega[ codigoentrega=" + codigoentrega + " ]";
    }
    
}
