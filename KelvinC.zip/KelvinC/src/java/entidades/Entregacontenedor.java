/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package entidades;

import java.io.Serializable;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "entregacontenedor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Entregacontenedor.findAll", query = "SELECT e FROM Entregacontenedor e")
    , @NamedQuery(name = "Entregacontenedor.findByUnidadesretiradascontenedor", query = "SELECT e FROM Entregacontenedor e WHERE e.unidadesretiradascontenedor = :unidadesretiradascontenedor")
    , @NamedQuery(name = "Entregacontenedor.findByCodigoentregacontenedor", query = "SELECT e FROM Entregacontenedor e WHERE e.codigoentregacontenedor = :codigoentregacontenedor")})
public class Entregacontenedor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "unidadesretiradascontenedor")
    private short unidadesretiradascontenedor;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigoentregacontenedor")
    private Short codigoentregacontenedor;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codigoentregacontenedor")
    private List<Entregahabitante> entregahabitanteList;
    @JoinColumn(name = "codigocontenedor", referencedColumnName = "codigocontenedor")
    @ManyToOne(optional = false)
    private Contenedor codigocontenedor;
    @JoinColumn(name = "codigoentrega", referencedColumnName = "codigoentrega")
    @ManyToOne(optional = false)
    private Entrega codigoentrega;

    public Entregacontenedor() {
    }

    public Entregacontenedor(Short codigoentregacontenedor) {
        this.codigoentregacontenedor = codigoentregacontenedor;
    }

    public Entregacontenedor(Short codigoentregacontenedor, short unidadesretiradascontenedor) {
        this.codigoentregacontenedor = codigoentregacontenedor;
        this.unidadesretiradascontenedor = unidadesretiradascontenedor;
    }

    public short getUnidadesretiradascontenedor() {
        return unidadesretiradascontenedor;
    }

    public void setUnidadesretiradascontenedor(short unidadesretiradascontenedor) {
        this.unidadesretiradascontenedor = unidadesretiradascontenedor;
    }

    public Short getCodigoentregacontenedor() {
        return codigoentregacontenedor;
    }

    public void setCodigoentregacontenedor(Short codigoentregacontenedor) {
        this.codigoentregacontenedor = codigoentregacontenedor;
    }

    @XmlTransient
    public List<Entregahabitante> getEntregahabitanteList() {
        return entregahabitanteList;
    }

    public void setEntregahabitanteList(List<Entregahabitante> entregahabitanteList) {
        this.entregahabitanteList = entregahabitanteList;
    }

    public Contenedor getCodigocontenedor() {
        return codigocontenedor;
    }

    public void setCodigocontenedor(Contenedor codigocontenedor) {
        this.codigocontenedor = codigocontenedor;
    }

    public Entrega getCodigoentrega() {
        return codigoentrega;
    }

    public void setCodigoentrega(Entrega codigoentrega) {
        this.codigoentrega = codigoentrega;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoentregacontenedor != null ? codigoentregacontenedor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Entregacontenedor)) {
            return false;
        }
        Entregacontenedor other = (Entregacontenedor) object;
        if ((this.codigoentregacontenedor == null && other.codigoentregacontenedor != null) || (this.codigoentregacontenedor != null && !this.codigoentregacontenedor.equals(other.codigoentregacontenedor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "entidades.Entregacontenedor[ codigoentregacontenedor=" + codigoentregacontenedor + " ]";
    }
    
}
