/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.Serializable;
import java.text.ParseException;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import modelo.entidades.Contenedor;
import modelo.entidades.Proveedor;
import modelo.session.beans.ContenedorFacade;
import modelo.session.beans.ProveedorFacade;

/**
 *
 * @author boni
 */
@ManagedBean(name = "consultaContenedores")
@ViewScoped
public class ConsultaContenedores implements Serializable {

    @Inject
    private ContenedorFacade contenedorFacade;
    private Contenedor contenedorSelected;
    private List<Contenedor> contenedoresLst;
    private List<String> fechas;
    private String fechaSelected;

    @Inject
    private ProveedorFacade proveedorFacade;
    private Proveedor proveedorSelected;
    private List<Proveedor> proveedoresLst;

    private Query q;

    public ConsultaContenedores() {
    }

    @PostConstruct
    public void Init() {
        proveedorSelected = new Proveedor();
        contenedorSelected = new Contenedor();
        buscarTodosProveedores();
        buscarTodosContenedores();
        buscarTodasFechas();
    }

    public List<Proveedor> buscarTodosProveedores() {
        proveedoresLst = proveedorFacade.findAll();
        return proveedoresLst;
    }

    public void buscarTodasFechas() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT contenedor.fechaadquisicion FROM contenedor GROUP BY contenedor.fechaadquisicion";
        q = em.createNativeQuery(jpql);
        fechas = q.getResultList();
        em.close();
        emf.close();
    }

    public void buscarTodosContenedores() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT contenedor.codigocontenedor, contenedor.cantidadcanastas, contenedor.fechaadquisicion,\n"
                + "proveedor.nombreproveedor FROM contenedor INNER JOIN proveedor ON contenedor.codigoproveedor =\n"
                + "proveedor.codigoproveedor";
        q = em.createNativeQuery(jpql);
        contenedoresLst = q.getResultList();
        em.close();
        emf.close();
 
    }

    public void buscarTodosContenedoresFiltrados() throws ParseException {
        try{
        if(this.proveedorSelected.getCodigoproveedor() != 0){
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT contenedor.codigocontenedor, contenedor.cantidadcanastas, contenedor.fechaadquisicion,\n"
                + "proveedor.nombreproveedor FROM contenedor INNER JOIN proveedor ON contenedor.codigoproveedor =\n"
                + "proveedor.codigoproveedor WHERE\n"
                + " proveedor.codigoproveedor =" + this.proveedorSelected.getCodigoproveedor() + " AND"
                + " contenedor.fechaadquisicion ='"+this.fechaSelected+"'";
        q = em.createNativeQuery(jpql);
        contenedoresLst = q.getResultList();
        em.close();
        emf.close();
        }else{
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORMACION", "POR FAVOR SELECCIONE AMBOS PARAMETROS")); 
        }
        }catch(Exception e){
        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "INFORMACION", "POR FAVOR SELECCIONE AMBOS PARAMETROS")); 
        }
    }

    public Contenedor getContenesorSelected() {
        return contenedorSelected;
    }

    public void setContenesorSelected(Contenedor contenesorSelected) {
        this.contenedorSelected = contenesorSelected;
    }

    public List<Contenedor> getContenedoresLst() {
        return contenedoresLst;
    }

    public void setContenedoresLst(List<Contenedor> contenedoresLst) {
        this.contenedoresLst = contenedoresLst;
    }

    public Proveedor getProveedorSelected() {
        return proveedorSelected;
    }

    public void setProveedorSelected(Proveedor proveedorSelected) {
        this.proveedorSelected = proveedorSelected;
    }

    public List<Proveedor> getProveedoresLst() {
        return proveedoresLst;
    }

    public void setProveedoresLst(List<Proveedor> proveedoresLst) {
        this.proveedoresLst = proveedoresLst;
    }

    public List<String> getFechas() {
        return fechas;
    }

    public void setFechas(List<String> fechas) {
        this.fechas = fechas;
    }

    public String getFechaSelected() {
        return fechaSelected;
    }

    public void setFechaSelected(String fechaSelected) {
        this.fechaSelected = fechaSelected;
    }


}
