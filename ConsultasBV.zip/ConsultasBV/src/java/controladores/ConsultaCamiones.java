/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.inject.Inject;
import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.Persistence;
import javax.persistence.Query;
import modelo.entidades.Camion;
import modelo.session.beans.CamionFacade;

/**
 *
 * @author boni
 */
@ManagedBean(name = "consultaCamiones")
@ViewScoped
public class ConsultaCamiones implements Serializable {

    @Inject
    CamionFacade camionFacade;
    List<Camion> camionLst;
    private Query q;

    public ConsultaCamiones() {
    }

    @PostConstruct
    public void Init() {
        buscarTodosCamiones();
    }

    public void buscarTodosCamiones() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT camion.placacamion, camion.marca, camion.modelo, camion.fechaadquisicion, camion.estadocamion from camion";
        q = em.createNativeQuery(jpql);
        camionLst = q.getResultList();
        em.close();
        emf.close();
    }

    public void buscarCamionesSinViajes() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT camion.placacamion, camion.marca, camion.modelo, camion.fechaadquisicion, camion.estadocamion\n"
                + "FROM camion WHERE NOT EXISTS(SELECT * FROM entrega WHERE entrega.placacamion = camion.placacamion)";
        q = em.createNativeQuery(jpql);
        camionLst = q.getResultList();
        em.close();
        emf.close();
    }

    public void buscarCamionesConViajes() {
        EntityManagerFactory emf = Persistence.createEntityManagerFactory("ConsultasBVPU");
        EntityManager em = emf.createEntityManager();
        String jpql = "SELECT camion.placacamion, camion.marca, camion.modelo, camion.fechaadquisicion, camion.estadocamion\n"
                + "FROM camion INNER JOIN entrega ON camion.placacamion = entrega.placacamion GROUP BY\n"
                + "camion.placacamion, camion.marca, camion.modelo, camion.fechaadquisicion, camion.estadocamion";
        q = em.createNativeQuery(jpql);
        camionLst = q.getResultList();
        em.close();
        emf.close();
    }

    public List<Camion> getCamionLst() {
        return camionLst;
    }
    
    public String estadoCamiones(boolean estadoCamion){
           if(estadoCamion == true){
           return "DISPONIBLE";
           }else{
           return "OCUPADO";
           }
    }

}
