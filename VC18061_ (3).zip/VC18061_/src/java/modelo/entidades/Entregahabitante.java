/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "entregahabitante")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Entregahabitante.findAll", query = "SELECT e FROM Entregahabitante e")
    , @NamedQuery(name = "Entregahabitante.findByCodigoentregahabitante", query = "SELECT e FROM Entregahabitante e WHERE e.codigoentregahabitante = :codigoentregahabitante")})
public class Entregahabitante implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigoentregahabitante")
    private Short codigoentregahabitante;
    @JoinColumn(name = "codigoentregacontenedor", referencedColumnName = "codigoentregacontenedor")
    @ManyToOne(optional = false)
    private Entregacontenedor codigoentregacontenedor;
    @JoinColumn(name = "duihabitante", referencedColumnName = "duihabitante")
    @ManyToOne(optional = false)
    private Habitante duihabitante;

    public Entregahabitante() {
    }

    public Entregahabitante(Short codigoentregahabitante) {
        this.codigoentregahabitante = codigoentregahabitante;
    }

    public Short getCodigoentregahabitante() {
        return codigoentregahabitante;
    }

    public void setCodigoentregahabitante(Short codigoentregahabitante) {
        this.codigoentregahabitante = codigoentregahabitante;
    }

    public Entregacontenedor getCodigoentregacontenedor() {
        return codigoentregacontenedor;
    }

    public void setCodigoentregacontenedor(Entregacontenedor codigoentregacontenedor) {
        this.codigoentregacontenedor = codigoentregacontenedor;
    }

    public Habitante getDuihabitante() {
        return duihabitante;
    }

    public void setDuihabitante(Habitante duihabitante) {
        this.duihabitante = duihabitante;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigoentregahabitante != null ? codigoentregahabitante.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Entregahabitante)) {
            return false;
        }
        Entregahabitante other = (Entregahabitante) object;
        if ((this.codigoentregahabitante == null && other.codigoentregahabitante != null) || (this.codigoentregahabitante != null && !this.codigoentregahabitante.equals(other.codigoentregahabitante))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Entregahabitante[ codigoentregahabitante=" + codigoentregahabitante + " ]";
    }
    
}
