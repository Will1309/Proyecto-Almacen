/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "camion")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Camion.findAll", query = "SELECT c FROM Camion c")
    , @NamedQuery(name = "Camion.findByPlacacamion", query = "SELECT c FROM Camion c WHERE c.placacamion = :placacamion")
    , @NamedQuery(name = "Camion.findByModelo", query = "SELECT c FROM Camion c WHERE c.modelo = :modelo")
    , @NamedQuery(name = "Camion.findByMarca", query = "SELECT c FROM Camion c WHERE c.marca = :marca")
    , @NamedQuery(name = "Camion.findByFechaadquisicion", query = "SELECT c FROM Camion c WHERE c.fechaadquisicion = :fechaadquisicion")
    , @NamedQuery(name = "Camion.findByEstadocamion", query = "SELECT c FROM Camion c WHERE c.estadocamion = :estadocamion")})
public class Camion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 8)
    @Column(name = "placacamion")
    private String placacamion;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "modelo")
    private String modelo;
    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 30)
    @Column(name = "marca")
    private String marca;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaadquisicion")
    @Temporal(TemporalType.DATE)
    private Date fechaadquisicion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "estadocamion")
    private boolean estadocamion;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "placacamion")
    private List<Entrega> entregaList;

    public Camion() {
    }

    public Camion(String placacamion) {
        this.placacamion = placacamion;
    }

    public Camion(String placacamion, String modelo, String marca, Date fechaadquisicion, boolean estadocamion) {
        this.placacamion = placacamion;
        this.modelo = modelo;
        this.marca = marca;
        this.fechaadquisicion = fechaadquisicion;
        this.estadocamion = estadocamion;
    }

    public String getPlacacamion() {
        return placacamion;
    }

    public void setPlacacamion(String placacamion) {
        this.placacamion = placacamion;
    }

    public String getModelo() {
        return modelo;
    }

    public void setModelo(String modelo) {
        this.modelo = modelo;
    }

    public String getMarca() {
        return marca;
    }

    public void setMarca(String marca) {
        this.marca = marca;
    }

    public Date getFechaadquisicion() {
        return fechaadquisicion;
    }

    public void setFechaadquisicion(Date fechaadquisicion) {
        this.fechaadquisicion = fechaadquisicion;
    }

    public boolean getEstadocamion() {
        return estadocamion;
    }

    public void setEstadocamion(boolean estadocamion) {
        this.estadocamion = estadocamion;
    }

    @XmlTransient
    public List<Entrega> getEntregaList() {
        return entregaList;
    }

    public void setEntregaList(List<Entrega> entregaList) {
        this.entregaList = entregaList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (placacamion != null ? placacamion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Camion)) {
            return false;
        }
        Camion other = (Camion) object;
        if ((this.placacamion == null && other.placacamion != null) || (this.placacamion != null && !this.placacamion.equals(other.placacamion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Camion[ placacamion=" + placacamion + " ]";
    }
    
}
