/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "devolucion")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Devolucion.findAll", query = "SELECT d FROM Devolucion d")
    , @NamedQuery(name = "Devolucion.findByCodigodevolucion", query = "SELECT d FROM Devolucion d WHERE d.codigodevolucion = :codigodevolucion")
    , @NamedQuery(name = "Devolucion.findByCodigocontenedor", query = "SELECT d FROM Devolucion d WHERE d.codigocontenedor = :codigocontenedor")
    , @NamedQuery(name = "Devolucion.findByCanastasretiradas", query = "SELECT d FROM Devolucion d WHERE d.canastasretiradas = :canastasretiradas")
    , @NamedQuery(name = "Devolucion.findByTotalentregadas", query = "SELECT d FROM Devolucion d WHERE d.totalentregadas = :totalentregadas")
    , @NamedQuery(name = "Devolucion.findByTotaldevolucion", query = "SELECT d FROM Devolucion d WHERE d.totaldevolucion = :totaldevolucion")})
public class Devolucion implements Serializable {

    private static final long serialVersionUID = 1L;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigodevolucion")
    private Integer codigodevolucion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "codigocontenedor")
    private int codigocontenedor;
    @Basic(optional = false)
    @NotNull
    @Column(name = "canastasretiradas")
    private int canastasretiradas;
    @Basic(optional = false)
    @NotNull
    @Column(name = "totalentregadas")
    private int totalentregadas;
    @Basic(optional = false)
    @NotNull
    @Column(name = "totaldevolucion")
    private int totaldevolucion;
    @JoinColumn(name = "codigoentrega", referencedColumnName = "codigoentrega")
    @ManyToOne(optional = false)
    private Entrega codigoentrega;

    public Devolucion() {
    }

    public Devolucion(Integer codigodevolucion) {
        this.codigodevolucion = codigodevolucion;
    }

    public Devolucion(Integer codigodevolucion, int codigocontenedor, int canastasretiradas, int totalentregadas, int totaldevolucion) {
        this.codigodevolucion = codigodevolucion;
        this.codigocontenedor = codigocontenedor;
        this.canastasretiradas = canastasretiradas;
        this.totalentregadas = totalentregadas;
        this.totaldevolucion = totaldevolucion;
    }

    public Integer getCodigodevolucion() {
        return codigodevolucion;
    }

    public void setCodigodevolucion(Integer codigodevolucion) {
        this.codigodevolucion = codigodevolucion;
    }

    public int getCodigocontenedor() {
        return codigocontenedor;
    }

    public void setCodigocontenedor(int codigocontenedor) {
        this.codigocontenedor = codigocontenedor;
    }

    public int getCanastasretiradas() {
        return canastasretiradas;
    }

    public void setCanastasretiradas(int canastasretiradas) {
        this.canastasretiradas = canastasretiradas;
    }

    public int getTotalentregadas() {
        return totalentregadas;
    }

    public void setTotalentregadas(int totalentregadas) {
        this.totalentregadas = totalentregadas;
    }

    public int getTotaldevolucion() {
        return totaldevolucion;
    }

    public void setTotaldevolucion(int totaldevolucion) {
        this.totaldevolucion = totaldevolucion;
    }

    public Entrega getCodigoentrega() {
        return codigoentrega;
    }

    public void setCodigoentrega(Entrega codigoentrega) {
        this.codigoentrega = codigoentrega;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigodevolucion != null ? codigodevolucion.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Devolucion)) {
            return false;
        }
        Devolucion other = (Devolucion) object;
        if ((this.codigodevolucion == null && other.codigodevolucion != null) || (this.codigodevolucion != null && !this.codigodevolucion.equals(other.codigodevolucion))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Devolucion[ codigodevolucion=" + codigodevolucion + " ]";
    }
    
}
