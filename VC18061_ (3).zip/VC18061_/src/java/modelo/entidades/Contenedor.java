/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package modelo.entidades;

import java.io.Serializable;
import java.util.Date;
import java.util.List;
import javax.persistence.Basic;
import javax.persistence.CascadeType;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;
import javax.persistence.NamedQueries;
import javax.persistence.NamedQuery;
import javax.persistence.OneToMany;
import javax.persistence.Table;
import javax.persistence.Temporal;
import javax.persistence.TemporalType;
import javax.validation.constraints.NotNull;
import javax.xml.bind.annotation.XmlRootElement;
import javax.xml.bind.annotation.XmlTransient;

/**
 *
 * @author informatica
 */
@Entity
@Table(name = "contenedor")
@XmlRootElement
@NamedQueries({
    @NamedQuery(name = "Contenedor.findAll", query = "SELECT c FROM Contenedor c")
    , @NamedQuery(name = "Contenedor.findByFechaadquisicion", query = "SELECT c FROM Contenedor c WHERE c.fechaadquisicion = :fechaadquisicion")
    , @NamedQuery(name = "Contenedor.findByCantidadcanastas", query = "SELECT c FROM Contenedor c WHERE c.cantidadcanastas = :cantidadcanastas")
    , @NamedQuery(name = "Contenedor.findByCodigocontenedor", query = "SELECT c FROM Contenedor c WHERE c.codigocontenedor = :codigocontenedor")})
public class Contenedor implements Serializable {

    private static final long serialVersionUID = 1L;
    @Basic(optional = false)
    @NotNull
    @Column(name = "fechaadquisicion")
    @Temporal(TemporalType.DATE)
    private Date fechaadquisicion;
    @Basic(optional = false)
    @NotNull
    @Column(name = "cantidadcanastas")
    private short cantidadcanastas;
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    @Basic(optional = false)
    @Column(name = "codigocontenedor")
    private Short codigocontenedor;
    @JoinColumn(name = "codigoproveedor", referencedColumnName = "codigoproveedor")
    @ManyToOne(optional = false)
    private Proveedor codigoproveedor;
    @OneToMany(cascade = CascadeType.ALL, mappedBy = "codigocontenedor")
    private List<Entregacontenedor> entregacontenedorList;

    public Contenedor() {
    }

    public Contenedor(Short codigocontenedor) {
        this.codigocontenedor = codigocontenedor;
    }

    public Contenedor(Short codigocontenedor, Date fechaadquisicion, short cantidadcanastas) {
        this.codigocontenedor = codigocontenedor;
        this.fechaadquisicion = fechaadquisicion;
        this.cantidadcanastas = cantidadcanastas;
    }

    public Date getFechaadquisicion() {
        return fechaadquisicion;
    }

    public void setFechaadquisicion(Date fechaadquisicion) {
        this.fechaadquisicion = fechaadquisicion;
    }

    public short getCantidadcanastas() {
        return cantidadcanastas;
    }

    public void setCantidadcanastas(short cantidadcanastas) {
        this.cantidadcanastas = cantidadcanastas;
    }

    public Short getCodigocontenedor() {
        return codigocontenedor;
    }

    public void setCodigocontenedor(Short codigocontenedor) {
        this.codigocontenedor = codigocontenedor;
    }

    public Proveedor getCodigoproveedor() {
        return codigoproveedor;
    }

    public void setCodigoproveedor(Proveedor codigoproveedor) {
        this.codigoproveedor = codigoproveedor;
    }

    @XmlTransient
    public List<Entregacontenedor> getEntregacontenedorList() {
        return entregacontenedorList;
    }

    public void setEntregacontenedorList(List<Entregacontenedor> entregacontenedorList) {
        this.entregacontenedorList = entregacontenedorList;
    }

    @Override
    public int hashCode() {
        int hash = 0;
        hash += (codigocontenedor != null ? codigocontenedor.hashCode() : 0);
        return hash;
    }

    @Override
    public boolean equals(Object object) {
        // TODO: Warning - this method won't work in the case the id fields are not set
        if (!(object instanceof Contenedor)) {
            return false;
        }
        Contenedor other = (Contenedor) object;
        if ((this.codigocontenedor == null && other.codigocontenedor != null) || (this.codigocontenedor != null && !this.codigocontenedor.equals(other.codigocontenedor))) {
            return false;
        }
        return true;
    }

    @Override
    public String toString() {
        return "modelo.entidades.Contenedor[ codigocontenedor=" + codigocontenedor + " ]";
    }
    
}
