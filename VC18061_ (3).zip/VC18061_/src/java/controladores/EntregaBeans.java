/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package controladores;

import java.io.Serializable;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Objects;
import javax.annotation.PostConstruct;
import javax.faces.application.FacesMessage;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ViewScoped;
import javax.faces.context.FacesContext;
import javax.inject.Inject;
import javax.persistence.Query;
import modelo.entidades.Camion;
import modelo.entidades.Canton;
import modelo.entidades.Contenedor;
import modelo.entidades.Devolucion;
import modelo.entidades.Empleado;
import modelo.entidades.Entrega;
import modelo.entidades.Entregacontenedor;
import modelo.session.beans.CamionFacade;
import modelo.session.beans.CantonFacade;
import modelo.session.beans.ContenedorFacade;
import modelo.session.beans.DevolucionFacade;
import modelo.session.beans.EmpleadoFacade;
import modelo.session.beans.EntregaFacade;
import modelo.session.beans.EntregacontenedorFacade;

/**
 *
 * @author informatica
 */
@ManagedBean(name = "enb")
@ViewScoped
public class EntregaBeans implements Serializable {

    ////////////////////////////////////////////////////////////////////////////
    @Inject
    private EntregacontenedorFacade entregaContenedorFacade;
    private Entregacontenedor entregaContenedorSeleccionado;
    private List<Entregacontenedor> entregaContenedorList;

    @Inject
    private ContenedorFacade contenedorFacade;
    private Contenedor contenedorSeleccionado;
    private List<Contenedor> contenedorList;

    @Inject
    private DevolucionFacade devolucionFacade;
    private Devolucion devolucionSeleccionada;
    private List<Devolucion> devolucionList;
    ////////////////////////////////////////////////////////////////////////////
    @Inject
    private EntregaFacade entregaFacade;
    private Entrega entregaSeleccionada;
    private List<Entrega> entregasList;

    @Inject
    private CamionFacade camionFacade;
    private Camion camionSeleccionado;
    private List<Camion> camionesList;

    @Inject
    private EmpleadoFacade empleadoFacade;
    private Empleado empleadoSeleccionado;
    private List<Empleado> empleadosList;

    @Inject
    private CantonFacade cantonFacade;
    private Canton cantonSeleccionado;
    private List<Canton> cantonesList;

    String fechaA;

    public EntregaBeans() {
    }

    @PostConstruct
    public void init() {
        ////////////////////////////////////////////////////////////////////////
        entregaContenedorSeleccionado = new Entregacontenedor();
        contenedorSeleccionado = new Contenedor();
        devolucionSeleccionada = new Devolucion();
        ////////////////////////////////////////////////////////////////////////
        entregaSeleccionada = new Entrega();
        camionSeleccionado = new Camion();
        empleadoSeleccionado = new Empleado();
        cantonSeleccionado = new Canton();

        Date f = new Date();
        this.entregaSeleccionada.setFechaentrega(f);
        DateFormat formato = new SimpleDateFormat("dd-MM-yyyy");
        fechaA = formato.format(f);

        buscarTodasEntregas();
        buscarTodosCamiones();
        buscarTodosEmpleados();
        buscarTodosCantones();
        ////////////////////////////////////////////////////////////////////////
        //buscarTodosContenedores();
        buscarTodasDevoluciones();
        ////////////////////////////////////////////////////////////////////////
    }

    ////////////////////////////////////////////////////////////////////////////////////////////////////////////
    public String ingresarDevoluciones() {
        Entrega x = null;
        boolean d = false;
        for (Entrega e : entregaFacade.findAll()) {
            if (Objects.equals(e.getCodigoentrega(), this.entregaSeleccionada.getCodigoentrega())) {
                x = e;
            }
        }

        List<Entregacontenedor> ec = entregaContenedorFacade.findAll();
        List<Entregacontenedor> ec2 = new ArrayList();
        for (Entregacontenedor e : ec) {
            if (e.getCodigoentrega().getCodigoentrega() == this.entregaSeleccionada.getCodigoentrega()) {
                ec2.add(e);
            }
        }

        for (Entregacontenedor e : ec2) {
            d = true;
            Devolucion devolucion = new Devolucion();
            devolucion.setCodigoentrega(x);////// le seteo la entrega
            devolucion.setCodigocontenedor(e.getCodigocontenedor().getCodigocontenedor());
            devolucion.setCanastasretiradas(e.getUnidadesretiradascontenedor());
            devolucion.setTotalentregadas(e.getEntregahabitanteList().size());
            devolucion.setTotaldevolucion(e.getUnidadesretiradascontenedor() - e.getEntregahabitanteList().size());
            devolucionFacade.create(devolucion);

            Contenedor y = null;
            int k= devolucion.getTotaldevolucion();
            for (Contenedor z : contenedorFacade.findAll()) {
                if (devolucion.getCodigocontenedor()==z.getCodigocontenedor()) {
                    y = z;
                    System.out.println("hola");
                }
            }
            y.setCantidadcanastas((short) (y.getCantidadcanastas()+ k));
            contenedorFacade.edit(y);
        }
        if(d == false){
         FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "No se puede finalizar por que nisiquiera se han asignado canastas a la entrega, sugerencia: si no la necesita borrela"));
        }

        return "TblEntrega.xhtml?faces-redirect=true";
    }
/////////////////////////////////////////////////////////////////////////////////////////////////////////

    public String getFechaA() {
        return fechaA;
    }

    public void setFechaA(String fechaA) {
        this.fechaA = fechaA;
    }

    public List<Devolucion> buscarTodasDevoluciones() {
        devolucionList = devolucionFacade.findAll();
        List<Devolucion> devolucionListFiltrada = new ArrayList();
        for (Devolucion x : devolucionList) {
            if (Objects.equals(x.getCodigoentrega().getCodigoentrega(), this.entregaSeleccionada.getCodigoentrega())) {
                devolucionListFiltrada.add(x);
            }
        }
        return devolucionListFiltrada;

    }

    public boolean validarBotones(int identrega) {
        boolean bandera = false;
        for (Devolucion d : this.devolucionList) {
            if (d.getCodigoentrega().getCodigoentrega() == identrega) {
                bandera = true;
                break;
            }
        }
        return bandera;
    }

    public boolean validarBotonesDevolucion(int identrega) {
        boolean bandera = true;
        for (Devolucion d : this.devolucionList) {
            if (d.getCodigoentrega().getCodigoentrega() == identrega) {
                bandera = false;
                break;
            }
        }
        return bandera;
    }

    public List<Contenedor> buscarTodosContenedores() {
        contenedorList = contenedorFacade.findAll();
        List<Contenedor> contenFiltrada = new ArrayList();
        for (int i = 0; i < contenedorList.size(); i++) {
            if (contenedorList.get(i).getCantidadcanastas() > 0) {
                contenFiltrada.add(contenedorList.get(i));
            }
        }
        return contenFiltrada;
    }

    public List<Entregacontenedor> buscarTodasEntregasContenedores() {
        entregaContenedorList = entregaContenedorFacade.findAll();
        List<Entregacontenedor> entreConteListFiltrada = new ArrayList();
        for (Entregacontenedor x : entregaContenedorList) {
            if (Objects.equals(x.getCodigoentrega().getCodigoentrega(), this.entregaSeleccionada.getCodigoentrega())) {
                entreConteListFiltrada.add(x);
            }
        }
        return entreConteListFiltrada;
    }

    public String insertarEntregaContenedor() {
        int k = 0;
        Contenedor y = null;
        for (Contenedor x : this.buscarTodosContenedores()) {
            if (Objects.equals(this.contenedorSeleccionado.getCodigocontenedor(), x.getCodigocontenedor())) {
                k = x.getCantidadcanastas();
                y = x;
            }
        }
        if (this.entregaContenedorSeleccionado.getUnidadesretiradascontenedor() <= k) {
            entregaContenedorSeleccionado.setCodigocontenedor(contenedorSeleccionado);
            entregaContenedorSeleccionado.setCodigoentrega(entregaSeleccionada);
            entregaContenedorFacade.create(entregaContenedorSeleccionado);
            y.setCantidadcanastas((short) (k - this.entregaContenedorSeleccionado.getUnidadesretiradascontenedor()));
            contenedorFacade.edit(y);
            return "TblEntrega.xhtml?faces-redirect=true";
        } else {
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Canastas Insuficientes"));
        }
        return "";
    }

    public EntregacontenedorFacade getEntregaContenedorFacade() {
        return entregaContenedorFacade;
    }

    public void setEntregaContenedorFacade(EntregacontenedorFacade entregaContenedorFacade) {
        this.entregaContenedorFacade = entregaContenedorFacade;
    }

    public Entregacontenedor getEntregaContenedorSeleccionado() {
        return entregaContenedorSeleccionado;
    }

    public void setEntregaContenedorSeleccionado(Entregacontenedor entregaContenedorSeleccionado) {
        this.entregaContenedorSeleccionado = entregaContenedorSeleccionado;
    }

    public List<Entregacontenedor> getEntregaContenedorList() {
        return entregaContenedorList;
    }

    public void setEntregaContenedorList(List<Entregacontenedor> entregaContenedorList) {
        this.entregaContenedorList = entregaContenedorList;
    }

    public ContenedorFacade getContenedorFacade() {
        return contenedorFacade;
    }

    public void setContenedorFacade(ContenedorFacade contenedorFacade) {
        this.contenedorFacade = contenedorFacade;
    }

    public Contenedor getContenedorSeleccionado() {
        return contenedorSeleccionado;
    }

    public void setContenedorSeleccionado(Contenedor contenedorSeleccionado) {
        this.contenedorSeleccionado = contenedorSeleccionado;
    }

    public List<Contenedor> getContenedorList() {
        return contenedorList;
    }

    public void setContenedorList(List<Contenedor> contenedorList) {
        this.contenedorList = contenedorList;
    }

    ////////////////////////////////////////////////////////////////////////////
    public List<Entrega> buscarTodasEntregas() {
        entregasList = entregaFacade.findAll();
        return entregasList;
    }

    public List<Camion> buscarTodosCamiones() {
        camionesList = camionFacade.findAll();
        List<Camion> camionFiltrada = new ArrayList();
        for (int i = 0; i < camionesList.size(); i++) {
            if (camionesList.get(i).getEstadocamion() == true) {
                camionFiltrada.add(camionesList.get(i));
            }
        }
        return camionFiltrada;
    }

    public List<Empleado> buscarTodosEmpleados() {
        empleadosList = empleadoFacade.findAll();
        List<Empleado> empleadoFiltrada = new ArrayList();
        for (int i = 0; i < empleadosList.size(); i++) {
            if (empleadosList.get(i).getEstadoempleado() == true) {
                empleadoFiltrada.add(empleadosList.get(i));
            }
        }
        return empleadoFiltrada;
    }

    public List<Canton> buscarTodosCantones() {
        cantonesList = cantonFacade.findAll();
        return cantonesList;
    }

    public String insertarEntrega() {
        Camion x = null;
        Empleado y = null;

        for (Camion c : this.buscarTodosCamiones()) {
            if (this.camionSeleccionado.getPlacacamion().equals(c.getPlacacamion())) {
                x = c;
            }
        }
        for (Empleado e : this.buscarTodosEmpleados()) {
            if (this.empleadoSeleccionado.getDuiempleado().equals(e.getDuiempleado())) {
                y = e;
            }
        }
        entregaSeleccionada.setPlacacamion(camionSeleccionado);
        entregaSeleccionada.setDuiempleado(empleadoSeleccionado);
        entregaSeleccionada.setCodigocantonentrega(cantonSeleccionado);
        entregaFacade.create(entregaSeleccionada);

        x.setEstadocamion(false);
        y.setEstadoempleado(false);
        camionFacade.edit(x);
        empleadoFacade.edit(y);
        return "TblEntrega.xhtml?faces-redirect=true";
    }

    public String eliminarEntrega() {
        boolean f = false;
        Empleado x = null;
        Camion y = null;

        this.buscarTodasEntregasContenedores();

        for (Entregacontenedor e : this.getEntregaContenedorList()) {
            if (e.getCodigoentrega().getCodigoentrega() == this.entregaSeleccionada.getCodigoentrega()) {
                f = true;
                break;
            }
        }
        if (f == false) { /// No tiene relaciones con otros registros
            for (Entrega en : this.entregasList) {
                if (en.getCodigoentrega() == this.entregaSeleccionada.getCodigoentrega()) {
                    x = en.getDuiempleado();
                    y = en.getPlacacamion();
                    x.setEstadoempleado(true);
                    y.setEstadocamion(true);
                    break;
                }
            }
            entregaFacade.remove(entregaSeleccionada);
            empleadoFacade.edit(x);
            camionFacade.edit(y);
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Datos Eliminados"));
            return "TblEntrega.xhtml?faces-redirect=true";
        } else { /// Si tiene relaciones/// Noborrar();
            FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "No se puede eliminar, tiene registros relacionados"));
            return "TblEntrega.xhtml?faces-redirect=true";
        }
    }

    public String modificarEntrega() {
        Camion x = null;
        Empleado y = null;
        Camion dosx = null;
        Empleado dosy = null;

        for (Entrega en : this.buscarTodasEntregas()) {
            if (this.entregaSeleccionada.getCodigoentrega() == en.getCodigoentrega()) {
                dosx = en.getPlacacamion();
                dosy = en.getDuiempleado();
            }
        }

        for (Camion c : this.buscarTodosCamiones()) {
            if (this.camionSeleccionado.getPlacacamion().equals(c.getPlacacamion())) {
                x = c;
            }
        }
        for (Empleado e : this.buscarTodosEmpleados()) {
            if (this.empleadoSeleccionado.getDuiempleado().equals(e.getDuiempleado())) {
                y = e;
            }
        }
        entregaSeleccionada.setPlacacamion(camionSeleccionado);
        entregaSeleccionada.setDuiempleado(empleadoSeleccionado);
        entregaSeleccionada.setCodigocantonentrega(cantonSeleccionado);
        entregaFacade.edit(entregaSeleccionada);

        if (x != null) {
            x.setEstadocamion(false);
            camionFacade.edit(x);
            System.out.println("soy x");
        }
        if (y != null) {
            y.setEstadoempleado(false);
            empleadoFacade.edit(y);
            System.out.println("soy y");
        }
        try {
            if (!dosx.getPlacacamion().equals(x.getPlacacamion())) {
                dosx.setEstadocamion(true);
                camionFacade.edit(dosx);
                System.out.println("soy dosx y solo soy necesario cuando al actualizar elgen otro camion");
            }
        } catch (Exception e) {
            System.out.println("no se modifico el camion");
        }
        try {
            if (!dosy.getDuiempleado().equals(y.getDuiempleado())) {
                dosy.setEstadoempleado(true);
                empleadoFacade.edit(dosy);
                System.out.println("soy dosy y solo soy necesario cuando al actualizar elgen otro empleado");
            }
        } catch (Exception e) {
            System.out.println("no se modifico el empleado");
        }

        FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, "Informacion", "Datos Eliminados"));
        return "TblEntrega.xhtml?faces-redirect=true";
    }

    public EntregaFacade getEntregaFacade() {
        return entregaFacade;
    }

    public void setEntregaFacade(EntregaFacade entregaFacade) {
        this.entregaFacade = entregaFacade;
    }

    public Entrega getEntregaSeleccionada() {
        return entregaSeleccionada;
    }

    public void setEntregaSeleccionada(Entrega entregaSeleccionada) {
        this.entregaSeleccionada = entregaSeleccionada;
    }

    public List<Entrega> getEntregasList() {
        return entregasList;
    }

    public void setEntregasList(List<Entrega> entregasList) {
        this.entregasList = entregasList;
    }

    public CamionFacade getCamionFacade() {
        return camionFacade;
    }

    public void setCamionFacade(CamionFacade camionFacade) {
        this.camionFacade = camionFacade;
    }

    public Camion getCamionSeleccionado() {
        return camionSeleccionado;
    }

    public void setCamionSeleccionado(Camion camionSeleccionado) {
        this.camionSeleccionado = camionSeleccionado;
    }

    public List<Camion> getCamionesList() {
        return camionesList;
    }

    public void setCamionesList(List<Camion> camionesList) {
        this.camionesList = camionesList;
    }

    public EmpleadoFacade getEmpleadoFacade() {
        return empleadoFacade;
    }

    public void setEmpleadoFacade(EmpleadoFacade empleadoFacade) {
        this.empleadoFacade = empleadoFacade;
    }

    public Empleado getEmpleadoSeleccionado() {
        return empleadoSeleccionado;
    }

    public void setEmpleadoSeleccionado(Empleado empleadoSeleccionado) {
        this.empleadoSeleccionado = empleadoSeleccionado;
    }

    public List<Empleado> getEmpleadosList() {
        return empleadosList;
    }

    public void setEmpleadosList(List<Empleado> empleadosList) {
        this.empleadosList = empleadosList;
    }

    public CantonFacade getCantonFacade() {
        return cantonFacade;
    }

    public void setCantonFacade(CantonFacade cantonFacade) {
        this.cantonFacade = cantonFacade;
    }

    public Canton getCantonSeleccionado() {
        return cantonSeleccionado;
    }

    public void setCantonSeleccionado(Canton cantonSeleccionado) {
        this.cantonSeleccionado = cantonSeleccionado;
    }

    public List<Canton> getCantonesList() {
        return cantonesList;
    }

    public void setCantonesList(List<Canton> cantonesList) {
        this.cantonesList = cantonesList;
    }

    public String formato(Date fecha) {
        DateFormat format = new SimpleDateFormat("dd-MM-yyyy");
        return (format.format(fecha));
    }

}
